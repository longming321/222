import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
from numpy.linalg import qr
import random
random.seed(225)
np.random.seed(225)
# Grouping
def split_matrix_randomly(matrix, n_groups):
    num_cols = matrix.shape[1]
    # Generating Index
    indices = np.arange(num_cols)
    np.random.shuffle(indices)
    shuffled_matrix = matrix[:, indices]
    cols_per_group = num_cols // n_groups
    remainder_cols = num_cols % n_groups
    groups = []
    start_col = 0
    for i in range(n_groups):
        if remainder_cols > 0:
            end_col = start_col + cols_per_group + 1
            remainder_cols -= 1
        else:
            end_col = start_col + cols_per_group
        group = shuffled_matrix[:, start_col:end_col]
        groups.append(group)
        start_col = end_col
    return groups
    
# Dimension
d = 100
# d = 500
scale = 10**(-6)
b = np.random.normal(0, 1, d)
B = np.reshape(b, (d, 1))
rm = np.random.normal(0, 1, d*d)
RM = np.reshape(rm, (d, d))
# QR Decomposition
Q, R = qr(RM)

diag1 = np.eye(d)*10
diag1[d-1][d-1] = 10.0 * np.sqrt(10)

# diag2 = np.eye(d)*10
# for i in range(d):
#     if i>79:
#         diag2[i][i] = 10.0 * np.sqrt(10)

# diag3 = np.eye(d)*10.0 * np.sqrt(5)
# diag3[d-1][d-1] = 100 * np.sqrt(5)

# diag4 = np.eye(d)*10.0 * np.sqrt(5)
# for i in range(d):
#     if i>479:
#         diag4[i][i] = 100 * np.sqrt(5)

A = Q@diag1@Q.T
M = A@A.T/d
eigenvalues = np.linalg.eigvals(M)
# Maximum eigenvalue
max_eigenvalue = np.max(np.real(eigenvalues))
# Minimum eigenvalue
min_eigenvalue = np.min(np.real(eigenvalues))
trace = np.trace(M)


# initialization
x = np.random.normal(0, 1, d)
x = np.reshape(x, (d, 1))
canshu = 
chengshu = 
distance_list = []
distance_list.append(np.linalg.norm(M@x-B, 2))

for i in range(200000):
    stepsize = 2.0 / (6*trace*canshu + chengshu*i*min_eigenvalue)
    u=np.random.normal(0, 1, d)
    u=np.reshape(u, (d, 1))
    # Given number of groups
    n_groups = 
    # Grouping
    groups = split_matrix_randomly(A, n_groups)
    # batchsize
    batchsize = A.shape[1]//n_groups
    for group in groups:
        sample=group
        f_Positive = (x + scale*u).T@sample@sample.T@(x + scale*u)/2.0/d - B.T@(x + scale*u)* batchsize /d
        f_Negative = (x - scale*u).T@sample@sample.T@(x - scale*u)/2.0/d - B.T@(x - scale*u)* batchsize /d
        gd = (f_Positive - f_Negative)/2.0/scale*u
        x = x - stepsize * gd
        distance = np.linalg.norm(M@x-B, 2)
        distance_list.append(distance)

df = pd.DataFrame(distance_list, columns=['coor'])
df.to_csv('data1gaussfirstorder.csv', index=False)