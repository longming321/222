import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']

# Experiment 1 and 2
df_coor = pd.read_csv('data1coor.csv')
df_gaussfirstorder = pd.read_csv('data1gaussfirstorder.csv')
coor_list = [200*i for i in range(21)]
gauss_list=[20000*i for i in range(21)]
coor_filtered = [df_coor.iloc[i, 0] for i in coor_list]
gauss_filtered = [df_gaussfirstorder.iloc[i, 0] for i in gauss_list]

coor_scaled = [20000*i for i in range(21)]

plt.title('Type：1')
plt.plot(coor_scaled, coor_filtered, 'bo-', label='ZSC', markersize=5)
plt.plot(gauss_list, gauss_filtered,'rs-', label='ZSG',markersize=5)
plt.legend() 
plt.xlabel('oracle calls')
plt.ylabel(r'f(x$^t$)-f(x$^*$)')
plt.yscale('log')
plt.savefig('data1.eps', format='eps', dpi=1000)
plt.show()

# # Experiment 3 and 4
# df_coor = pd.read_csv('data3coor.csv')
# df_gaussfirstorder = pd.read_csv('data3gaussfirstorder.csv')
# coor_list = [60*i for i in range(21)]
# gauss_list=[30000*i for i in range(21)]
# x_list=[30000*i for i in range(21)]

# coor_filtered = [df_coor.iloc[i, 0] for i in coor_list]
# gauss_filtered = [df_gaussfirstorder.iloc[i, 0] for i in gauss_list]

# plt.title('Type：3')
# plt.plot(x_list, coor_filtered, 'bo-', label='ZSC', markersize=5)
# plt.plot(x_list, gauss_filtered,'rs-', label='ZSG',markersize=5)
# plt.legend()  # 显示图例
# plt.xlabel('oracle calls')
# plt.ylabel(r'f(x$^t$)-f(x$^*$)')
# plt.yscale('log')
# plt.savefig('data3.eps', format='eps', dpi=1000)
# plt.show()